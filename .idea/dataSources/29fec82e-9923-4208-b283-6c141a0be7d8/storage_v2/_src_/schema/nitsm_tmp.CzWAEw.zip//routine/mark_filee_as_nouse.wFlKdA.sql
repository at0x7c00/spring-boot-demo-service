create procedure mark_filee_as_nouse(IN `_filee_id` int)
  BEGIN
	update sys_file f set f.inuse = 0 where f.id=_filee_id;
END;

