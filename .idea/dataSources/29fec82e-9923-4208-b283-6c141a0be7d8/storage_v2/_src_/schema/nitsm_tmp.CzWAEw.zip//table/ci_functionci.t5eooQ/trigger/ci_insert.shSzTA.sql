create trigger ci_insert
  after INSERT
  on ci_functionci
  for each row
  begin
call ci_type_total_nums_adjust(new.ci_type,1);
if new.data_sync_status='publish'  then
call ci_type_publish_nums_adjust(new.ci_type,1);
end if;
end;

