create trigger problem_file_delete
  after DELETE
  on lnk_problem_filee
  for each row
  begin
call mark_filee_as_nouse(old.filee_id);
end;

