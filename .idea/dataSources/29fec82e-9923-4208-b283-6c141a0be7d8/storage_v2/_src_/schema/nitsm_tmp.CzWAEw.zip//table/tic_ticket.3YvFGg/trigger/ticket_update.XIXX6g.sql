create trigger ticket_update
  after UPDATE
  on tic_ticket
  for each row
  begin
if old.agent=new.agent then
call engineer_statistics(new.agent);
else
call engineer_statistics(old.agent);
call engineer_statistics(new.agent);
end if;
if new.status='Closed' then
call ticket_type_statistics(new.ticket_type);
end if;
end;

