create trigger respository_attachement_delete
  after DELETE
  on lnk_respository_attachment
  for each row
  begin
call mark_filee_as_nouse(old.filee_id);
end;

