create procedure engineer_statistics(IN `_agent` varchar(255))
  BEGIN
	DECLARE _count INT;
	DECLARE _avg_time DOUBLE;
	SELECT COUNT(DISTINCT t.id) ,SUM(tt.aver_deal_nums) INTO _count,_avg_time 
		FROM tic_ticket AS t LEFT JOIN con_ticket_type tt ON t.ticket_type=tt.id
		WHERE t.agent=_agent AND t.`status` NOT IN('Revoke','Closed');
	UPDATE sys_user AS u 
		SET u.undone_nums=_count,u.remain_times=_avg_time 
		WHERE u.username=_agent;
END;

