create procedure ticket_type_statistics(IN `_ticket_type_id` int)
  BEGIN
	DECLARE _avg_time DOUBLE;
	SELECT avg(t.solve_totle_time) INTO _avg_time 
		FROM tic_ticket AS t 
		where t.ticket_type=_ticket_type_id AND t.`status` = 'Closed'
		ORDER BY t.id DESC
		LIMIT 0,100;
	UPDATE con_ticket_type AS tt 
		SET tt.aver_deal_nums=_avg_time 
		WHERE tt.id=_ticket_type_id;
END;

