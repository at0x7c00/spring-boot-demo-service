create procedure ci_type_publish_nums_adjust(IN `_ci_type_id` int, IN `_adjust_num` int)
  BEGIN
	update ci_type ct 
		set ct.publish_nums=ct.publish_nums + _adjust_num
		where ct.id = _ci_type_id;
END;

