create trigger ticket_filee_delete
  after DELETE
  on lnk_ticket_filee
  for each row
  begin
call mark_filee_as_nouse(old.filee_id);
end;

