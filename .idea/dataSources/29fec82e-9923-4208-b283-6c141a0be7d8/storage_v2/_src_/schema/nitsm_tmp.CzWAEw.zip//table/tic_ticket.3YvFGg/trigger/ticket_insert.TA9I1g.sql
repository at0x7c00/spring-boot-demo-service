create trigger ticket_insert
  after INSERT
  on tic_ticket
  for each row
  begin
call engineer_statistics(new.agent);
end;

