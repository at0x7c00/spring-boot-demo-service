create trigger document_file_delete
  after DELETE
  on sys_document_filee
  for each row
  begin
call mark_filee_as_nouse(old.filee_id);
end;

