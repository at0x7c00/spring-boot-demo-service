create trigger ci_update
  after UPDATE
  on ci_functionci
  for each row
  begin
if new.data_sync_status='publish' and old.data_sync_status !='publish'  then
call ci_type_publish_nums_adjust(new.ci_type,1);
elseif new.data_sync_status !='publish' and old.data_sync_status ='publish' then
call ci_type_publish_nums_adjust(old.ci_type,-1);
end if;
end;

